#include <stdio.h>
#include "myprog.h"

void step2()
{
  printf("step2\n");
}
