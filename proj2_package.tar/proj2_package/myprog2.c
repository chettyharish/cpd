#include <stdio.h>

void step1()
{

  printf("step1\n");
}
