#include <stdio.h>
#include <stdlib.h>

#include "myprog.h"
int main()
{ 
  int i;
  step1();
  step2();
  printf("main step.\n");
  exit(10);
  return 100;
}
